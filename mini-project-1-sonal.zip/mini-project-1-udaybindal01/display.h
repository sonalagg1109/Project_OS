#ifndef DISPLAY_H
#define DISPLAY_H


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pwd.h>
#include <limits.h>
#include <sys/stat.h>
#include <string.h>
#include "globals.h"


// extern char INPUT_MAIN[MAX_INPUT];
// extern char shell_home_directory[PATH_MAX];
// extern char username[100000];
// extern char hostname[100000];
// extern char current_directory[100000];
// extern char previous_dir[PATH_MAX];
// extern char process_name[4096];



void display_username_and_system();

#endif