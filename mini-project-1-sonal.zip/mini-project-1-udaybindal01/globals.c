#include "globals.h"


char INPUT_MAIN[MAX_INPUT];
char shell_home_directory[PATH_MAX];
char username[100000];
char hostname[100000];
char current_directory[100000];
char previous_dir[PATH_MAX] = "";
char process_name[4096];
char logpath[4096];

int time_flag = 0;
int flag =0;


char store[4096];

